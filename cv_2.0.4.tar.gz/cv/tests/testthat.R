library(testthat)
library(cv)

test_check("cv")
